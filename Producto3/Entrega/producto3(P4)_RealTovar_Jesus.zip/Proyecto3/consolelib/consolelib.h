#pragma once

#include <stdio.h>

int read_string(char *cad, int n);