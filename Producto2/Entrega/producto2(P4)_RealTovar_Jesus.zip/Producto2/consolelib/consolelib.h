#pragma once

#include <stdio.h>

void print_line_break();
void print_char(char c);
void print_msg(const char * msg);
void print_msg_int(const char * msg, int integer);
int ask_for_integer();
int read_string(char *cad, int n);